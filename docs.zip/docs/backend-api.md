# Backend API Reference

> **Base URL:** `http://rural-alb-dev-2139845854.ap-south-1.elb.amazonaws.com`
>
> **Total Endpoints:** 72 (23 Knowledge + 32 Agriculture + 7 Precision + 10 Economics)

## Common Headers

| Header | Required | Description |
|--------|----------|-------------|
| `X-User-Id` | Yes | User identifier (UUID). Passed automatically in dev; Cognito JWT in production. |
| `Content-Type` | For POST/PUT | `application/json` |
| `Authorization` | Production | `Bearer <cognito-jwt-token>` |

## Response Format

All endpoints return a standard wrapper:

```json
{
  "success": true,
  "data": { ... },
  "metadata": {
    "requestId": "uuid",
    "timestamp": "2026-03-01T12:00:00.000Z"
  }
}
```

Error responses:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Missing required field: cropType"
  }
}
```

---

## Health Check

```
GET /health
```

No authentication required. Used by ALB target group health checks.

**Response:**
```json
{
  "status": "healthy",
  "version": "2.0.0",
  "uptime": 1234.56,
  "timestamp": "2026-03-01T12:00:00.000Z",
  "environment": "production"
}
```

---

## 1. Knowledge & Learning (`/knowledge/*`)

### Courses

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/knowledge/courses` | List all available courses |
| `GET` | `/knowledge/courses/:id` | Get course by ID |
| `POST` | `/knowledge/courses` | Create a new course |
| `POST` | `/knowledge/courses/:id/enroll` | Enroll current user in a course |
| `GET` | `/knowledge/my-courses` | Get user's enrolled courses |
| `POST` | `/knowledge/courses/:courseId/modules/:moduleId/complete` | Mark module as completed |
| `GET` | `/knowledge/courses/:id/content` | Get all module content for a course |

#### `GET /knowledge/courses`

```bash
curl http://localhost:3000/knowledge/courses \
  -H "X-User-Id: demo-user"
```

**Response:**
```json
{
  "success": true,
  "data": [{
    "courseId": "organic-farming-101",
    "title": "Organic Farming Basics",
    "language": "hi",
    "difficulty": "beginner",
    "modules": [
      { "moduleId": "m1", "title": "Introduction", "duration": 15 }
    ]
  }]
}
```

#### `POST /knowledge/courses/:id/enroll`

```bash
curl -X POST http://localhost:3000/knowledge/courses/organic-farming-101/enroll \
  -H "X-User-Id: demo-user"
```

### Government Integration

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/knowledge/govt-courses` | List government courses |
| `GET` | `/knowledge/govt-courses/portals` | Get available government portals |
| `POST` | `/knowledge/govt-courses/sync` | Sync courses from government portals |

### Peer Groups

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/knowledge/peer-groups/join` | Find and join peer groups via clustering |
| `GET` | `/knowledge/peer-groups/my-groups` | Get user's groups |
| `GET` | `/knowledge/peer-groups/:id` | Get group details |
| `POST` | `/knowledge/peer-groups/:id/join` | Join a specific group |
| `POST` | `/knowledge/peer-groups/:id/leave` | Leave a group |
| `POST` | `/knowledge/peer-groups` | Create a new group |

### DigiLocker Verification

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/knowledge/peer-groups/verify/start` | Start DigiLocker verification |
| `POST` | `/knowledge/peer-groups/verify/complete` | Complete verification flow |

> **Note:** DigiLocker uses mock mode (`DIGILOCKER_USE_MOCK=true`) — no real API calls.

### Learning Intelligence

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/knowledge/recommendations` | Get AI-generated learning recommendations |
| `GET` | `/knowledge/recommendations/status` | Check if recommendations need refresh |
| `GET` | `/knowledge/learning-profile` | Get user's learning profile |
| `POST` | `/knowledge/learning-profile` | Create/update learning profile |
| `GET` | `/knowledge/progress-summary` | Get progress analytics summary |

#### `POST /knowledge/learning-profile`

```bash
curl -X POST http://localhost:3000/knowledge/learning-profile \
  -H "X-User-Id: demo-user" \
  -H "Content-Type: application/json" \
  -d '{
    "preferredLanguage": "hi",
    "educationLevel": "secondary",
    "farmingExperience": 5,
    "interests": ["organic-farming", "crop-rotation"]
  }'
```

---

## 2. Agriculture & Supply Chain (`/agriculture/*`)

### Supply Chain — Listings

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/agriculture/listings` | Create a produce listing |
| `GET` | `/agriculture/listings` | Search available listings |
| `GET` | `/agriculture/listings/my` | Get farmer's own listings |
| `GET` | `/agriculture/listings/:id` | Get listing details |
| `PUT` | `/agriculture/listings/:id/status` | Update listing status |

#### `POST /agriculture/listings`

```bash
curl -X POST http://localhost:3000/agriculture/listings \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "cropType": "wheat",
    "quantity": 500,
    "unit": "kg",
    "pricePerUnit": 25,
    "location": "Indore, MP",
    "harvestDate": "2026-03-15"
  }'
```

### Supply Chain — Buyers & Orders

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/agriculture/buyers/register` | Register as a buyer |
| `GET` | `/agriculture/buyers` | Search registered buyers |
| `GET` | `/agriculture/buyers/:id` | Get buyer details |
| `POST` | `/agriculture/buyers/:id/verify` | Verify a buyer |
| `POST` | `/agriculture/listings/:id/order` | Create trade order |
| `GET` | `/agriculture/orders` | Get user's orders |
| `PUT` | `/agriculture/orders/:id` | Update order status |

### Market Data — Prices

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/agriculture/prices/:crop` | Get current prices for a crop |
| `GET` | `/agriculture/prices/:crop/trend` | Get price trend (7/30/90 days) |
| `GET` | `/agriculture/mandis` | List available mandis (markets) |
| `GET` | `/agriculture/mandis/:name/prices` | Get all prices at a specific mandi |
| `POST` | `/agriculture/prices/ingest` | Ingest price data (admin) |

#### `GET /agriculture/prices/wheat`

```bash
curl http://localhost:3000/agriculture/prices/wheat \
  -H "X-User-Id: demo-user"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "crop": "wheat",
    "prices": [
      { "mandi": "Indore", "price": 2250, "unit": "quintal", "date": "2026-03-01" },
      { "mandi": "Bhopal", "price": 2180, "unit": "quintal", "date": "2026-03-01" }
    ]
  }
}
```

### Market Data — Alerts

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/agriculture/alerts` | Subscribe to price alert |
| `GET` | `/agriculture/alerts` | Get user's active alerts |
| `DELETE` | `/agriculture/alerts/:id` | Delete an alert |
| `POST` | `/agriculture/alerts/check` | Dispatch price alerts (cron trigger) |

#### `POST /agriculture/alerts`

```bash
curl -X POST http://localhost:3000/agriculture/alerts \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "crop": "wheat",
    "targetPrice": 2300,
    "direction": "above",
    "mandi": "Indore"
  }'
```

### Collective Bargaining

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/agriculture/bargaining/groups` | Create bargaining group |
| `GET` | `/agriculture/bargaining/groups` | Search groups |
| `GET` | `/agriculture/bargaining/groups/:id` | Get group details |
| `POST` | `/agriculture/bargaining/groups/:id/join` | Join a group |
| `GET` | `/agriculture/bargaining/suggest` | AI-suggested groups for a farmer |

### Logistics & Transport

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/agriculture/logistics` | Create transport request |
| `GET` | `/agriculture/logistics` | Get user's transport requests |
| `GET` | `/agriculture/logistics/vehicles` | Get available vehicle types |
| `GET` | `/agriculture/logistics/:id` | Get request details |
| `PUT` | `/agriculture/logistics/:id` | Update request status |
| `POST` | `/agriculture/logistics/estimate` | Estimate transport cost |

#### `POST /agriculture/logistics/estimate`

```bash
curl -X POST http://localhost:3000/agriculture/logistics/estimate \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "origin": "Village Rampura, Indore",
    "destination": "Indore Mandi",
    "weight": 500,
    "vehicleType": "mini-truck"
  }'
```

---

## 3. Precision Agriculture (`/agriculture/precision/*`)

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/agriculture/precision/analyze` | Analyze farm image (soil/crop health) |
| `POST` | `/agriculture/precision/pest-disease/analyze` | Detect pests and diseases |
| `POST` | `/agriculture/precision/carbon/calculate` | Calculate carbon footprint score |
| `POST` | `/agriculture/precision/weather/advisory` | Get weather-based advisory |
| `POST` | `/agriculture/precision/practices/analyze` | Analyze farming practices |
| `POST` | `/agriculture/precision/practices/log` | Log a farming practice |
| `GET` | `/agriculture/precision/practices/logs` | Get practice history |

#### `POST /agriculture/precision/weather/advisory`

```bash
curl -X POST http://localhost:3000/agriculture/precision/weather/advisory \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "location": { "lat": 22.7196, "lon": 75.8577 },
    "crop": "wheat",
    "growthStage": "flowering"
  }'
```

#### `POST /agriculture/precision/carbon/calculate`

```bash
curl -X POST http://localhost:3000/agriculture/precision/carbon/calculate \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "farmSize": 2.5,
    "cropType": "rice",
    "practices": ["organic-fertilizer", "drip-irrigation"],
    "machineHours": 10
  }'
```

---

## 4. Economic Services (`/economics/*`)

### Profile

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/economics/profile` | Get user's economic profile |
| `POST` | `/economics/profile` | Create/update economic profile |

#### `POST /economics/profile`

```bash
curl -X POST http://localhost:3000/economics/profile \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "annualIncome": 150000,
    "landHolding": 2.5,
    "category": "small-farmer",
    "state": "MP",
    "crops": ["wheat", "soybean"]
  }'
```

### Government Schemes

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/economics/schemes` | Filter government schemes |
| `GET` | `/economics/schemes/:id` | Get scheme details |

#### `GET /economics/schemes?category=small-farmer&state=MP`

Returns filtered list of government schemes the farmer may be eligible for.

### Financial Services

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/economics/eligibility/assess` | Assess loan eligibility (AI-powered) |
| `POST` | `/economics/savings/plan` | Generate personalized savings plan |
| `POST` | `/economics/insurance/claims` | Submit an insurance claim |
| `GET` | `/economics/insurance/claims` | List user's insurance claims |
| `POST` | `/economics/nudges/generate` | Generate financial nudge (AI) |
| `GET` | `/economics/nudges` | List financial nudges |

#### `POST /economics/eligibility/assess`

```bash
curl -X POST http://localhost:3000/economics/eligibility/assess \
  -H "X-User-Id: farmer-001" \
  -H "Content-Type: application/json" \
  -d '{
    "loanType": "kcc",
    "amount": 100000
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "eligible": true,
    "score": 72,
    "maxAmount": 150000,
    "interestRate": 4,
    "recommendations": ["Consider KCC with 4% interest rate subsidy"]
  }
}
```

---

## Rate Limiting

- **200 requests/minute** per user (by `X-User-Id` header or IP)
- Health check endpoint is exempt
- Returns `429 Too Many Requests` when exceeded

## Error Codes

| HTTP Status | Code | Meaning |
|-------------|------|---------|
| 400 | `VALIDATION_ERROR` | Missing/invalid request parameters |
| 401 | `UNAUTHORIZED` | Missing or invalid auth token |
| 404 | `NOT_FOUND` | Resource not found |
| 429 | `RATE_LIMITED` | Too many requests |
| 500 | `INTERNAL_ERROR` | Server error |
