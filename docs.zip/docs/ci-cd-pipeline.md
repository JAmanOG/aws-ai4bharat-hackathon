# CI/CD Pipeline

## Overview

The project uses **GitHub Actions** for continuous integration and deployment. Two workflows handle testing and production deployment.

```
Developer pushes code
        │
        ├── Push to develop / PR to main
        │       └── ci.yml → Run tests (85 unit tests)
        │
        └── Push to main (backend/** or infra/**)
                └── deploy.yml
                    ├── Job 1: test    → npm test
                    ├── Job 2: build   → Docker build → ECR push
                    └── Job 3: deploy  → CloudFormation → ECS update → Health check
```

---

## Workflow 1: CI — Test & Lint

**File:** `.github/workflows/ci.yml`

**Triggers:**
- Pull requests to `main` or `develop` (when `backend/**` changes)
- Push to `develop`

**What it does:**
1. Checks out code
2. Sets up Node.js 20 with npm cache
3. Runs `npm ci` in `backend/`
4. Runs `npm test -- --ci --coverage --forceExit`
5. Uploads coverage report as artifact (7-day retention)

**No AWS credentials needed** — purely runs unit tests.

---

## Workflow 2: Deploy Backend

**File:** `.github/workflows/deploy.yml`

**Triggers:**
- Push to `main` branch (when `backend/**`, `infra/ecs.yaml`, or the workflow itself changes)
- Manual trigger via `workflow_dispatch` (choose stage: dev/staging/prod)

### Job Flow

```
test (1 min)  ──>  build (2-3 min)  ──>  deploy (3-5 min)
    │                    │                     │
    │ npm test           │ Docker build        │ CloudFormation deploy
    │ 85 tests           │ ECR push            │ ECS service update
    │                    │ Output: image URI    │ Health check
    └────────────────────┴─────────────────────┘
```

### Job 1: Test
- Identical to CI workflow — ensures no broken code reaches production

### Job 2: Build
- Configures AWS credentials from secrets
- Logs into ECR
- Builds Docker image from `./backend/Dockerfile`
- Tags with: `$REGISTRY/rural-platform-backend:$GIT_SHA` and `:latest`
- Pushes both tags to ECR
- Outputs image URI for deploy job

### Job 3: Deploy
- Runs `aws cloudformation deploy` with `infra/ecs.yaml`
- Stack name: `rural-platform-ecs-{stage}` (default: `rural-platform-ecs-dev`)
- Passes all infrastructure params from GitHub Secrets
- Waits 60 seconds for service stabilization
- Runs health check against ALB URL

---

## GitHub Secrets

Go to **github.com/JAmanOG/aws-ai4bharat-hackathon** → **Settings** → **Secrets and variables** → **Actions**

### Required Secrets

| Secret | Value | Description |
|--------|-------|-------------|
| `AWS_ACCESS_KEY_ID` | `AKIART4IVBYSZ7NSQYUZ` | IAM user: `github-actions-deployer` |
| `AWS_SECRET_ACCESS_KEY` | *(stored securely)* | Secret key for the deployer user |
| `VPC_ID` | `vpc-0caeb0d2ebe85e669` | Default VPC in ap-south-1 |
| `SUBNET_IDS` | `subnet-00102fd8f02546f3f,subnet-0de9101cc6a6f388f,subnet-0372f717ad5bf8f18` | 3 public subnets (AZs a,b,c) |
| `COGNITO_USER_POOL_ID` | `ap-south-1_5eGqm0JvM` | Cognito pool |
| `COGNITO_APP_CLIENT_ID` | `7037npivotg1kmnf5pm0cd1und` | Cognito app client |
| `CONTENT_BUCKET` | `rural-platform-content-dev-111418871333` | S3 bucket for course content |
| `COMMUNITY_MEDIA_BUCKET` | `rural-community-media-dev-111418871333` | S3 bucket for community media |
| `HEALTH_IMAGING_BUCKET` | `rural-health-imaging-dev-111418871333` | S3 bucket for health images |
| `PRICE_ALERT_SNS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-price-alerts-dev` | SNS topic |
| `FINANCIAL_NOTIFICATIONS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-financial-notifications-dev` | SNS topic |
| `LEARNING_NOTIFICATIONS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-learning-notifications-dev` | SNS topic |
| `COMMUNITY_NOTIFICATIONS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-community-notifications-dev` | SNS topic |

### Optional Secrets (for PostgreSQL — not currently used)

| Secret | Default | Description |
|--------|---------|-------------|
| `DB_HOST` | `''` | Aurora/RDS endpoint |
| `DB_PASSWORD` | `''` | Database password |

---

## IAM Deployer Permissions

The `github-actions-deployer` IAM user has these permissions:

| Service | Actions | Purpose |
|---------|---------|---------|
| **ECR** | Get/Put/Upload layers, GetAuthorizationToken | Push Docker images |
| **ECS** | Full (`ecs:*`) | Register task definitions, update services |
| **IAM** | GetRole, CreateRole, PutRolePolicy, PassRole, etc. | CloudFormation creates IAM roles |
| **CloudFormation** | Full (`cloudformation:*`) | Deploy/update/delete stacks |
| **ELB** | Full (`elasticloadbalancing:*`) | Create/manage ALB and target groups |
| **EC2** | Describe + Create/Delete SecurityGroups | Manage VPC security groups |
| **Logs** | Create/Delete LogGroup, PutRetentionPolicy | CloudWatch log management |
| **App Auto Scaling** | Full | ECS auto-scaling policies |

---

## Manual Deployment

For local deployment without GitHub Actions:

```bash
# From project root
./infra/deploy.sh dev       # Build → Push → CloudFormation deploy
./infra/deploy.sh staging   # Same for staging
./infra/deploy.sh prod      # Same for production
```

**Prerequisites:**
- Docker installed and running
- AWS CLI configured with appropriate credentials
- `.env` file present in project root

---

## Troubleshooting

### "Failed to create/update the stack"

```bash
# Check the specific error:
aws cloudformation describe-stack-events \
  --stack-name rural-platform-ecs-dev \
  --region ap-south-1 \
  --query 'StackEvents[?ResourceStatus==`CREATE_FAILED` || ResourceStatus==`UPDATE_FAILED`].[LogicalResourceId,ResourceStatusReason]' \
  --output table
```

**Common causes:**
- `iam:GetRole` denied → IAM policy missing permissions (fixed 2026-03-01)
- "Character sets beyond ASCII" → Non-ASCII chars in security group descriptions (fixed)
- "DependentServices" error → Wrong property name, should be `DependsOn` (fixed)

### Stack stuck in `ROLLBACK_IN_PROGRESS`

```bash
# Wait for rollback to complete
aws cloudformation wait stack-rollback-complete \
  --stack-name rural-platform-ecs-dev --region ap-south-1

# Or delete and recreate
aws cloudformation delete-stack \
  --stack-name rural-platform-ecs-dev --region ap-south-1
aws cloudformation wait stack-delete-complete \
  --stack-name rural-platform-ecs-dev --region ap-south-1
```

### ECR login expired

```bash
aws ecr get-login-password --region ap-south-1 | \
  docker login --username AWS --password-stdin \
  111418871333.dkr.ecr.ap-south-1.amazonaws.com
```

### ECS task failing to start

```bash
# Check task stopped reason
aws ecs list-tasks --cluster rural-dev --desired-status STOPPED --region ap-south-1
aws ecs describe-tasks --cluster rural-dev --tasks <task-arn> --region ap-south-1 \
  --query 'tasks[0].{status:lastStatus,reason:stoppedReason,container:containers[0].reason}'

# Check CloudWatch logs
aws logs tail /ecs/rural-dev --region ap-south-1 --since 1h --follow
```

### Re-trigger deployment

Go to **Actions** tab on GitHub → **Deploy Backend** → **Run workflow** → Select branch `main` and stage `dev`.

---

## Cost Impact

The CI/CD pipeline itself is free (GitHub Actions free tier: 2,000 min/month). AWS costs are only for the deployed infrastructure — see the [Deployment Guide](deployment-guide.md) for cost breakdown.
