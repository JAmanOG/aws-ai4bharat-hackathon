# Frontend Guide — RuralAi (React Native / Expo)

## Tech Stack

| Library | Version | Purpose |
|---------|---------|---------|
| Expo | 54.0 | Build toolchain, managed workflow |
| React Native | 0.81 | Cross-platform UI |
| React | 19.1 | Component framework |
| React Navigation | 7.x | Stack + bottom-tab navigation |
| TypeScript | 5.9 | Static typing |
| @expo/vector-icons | 15.x | Ionicons icon set |

No additional state management (Redux, Zustand, etc.) — screens use local state + custom hooks.

---

## Quick Start

```bash
cd RuralAi

# Install dependencies
npm install

# Start Expo dev server
npx expo start

# Platform-specific
npx expo start --android   # Android emulator / device
npx expo start --ios       # iOS simulator (macOS only)
npx expo start --web       # Browser (React Native Web)
```

### Point to Production API

```bash
EXPO_PUBLIC_API_URL=http://rural-alb-dev-2139845854.ap-south-1.elb.amazonaws.com \
  npx expo start
```

---

## Project Structure

```
RuralAi/
├── App.tsx                        # Entry — wraps RootNavigator in NavigationContainer
├── index.ts                       # Expo entry point
├── package.json
├── tsconfig.json
└── src/
    ├── config/
    │   └── env.ts                 # API_BASE_URL, DEMO_USER_ID, timeouts
    ├── services/
    │   └── api.ts                 # Fetch wrapper + 7 domain API namespaces
    ├── hooks/
    │   ├── useApi.ts              # Generic async-data hook (loading/error/refresh)
    │   └── useData.ts            # Domain hooks wrapping useApi + api calls
    ├── components/
    │   └── ui.tsx                 # LoadingView, ErrorView, EmptyView, SyncPill
    ├── theme/
    │   ├── colors.ts              # Blue/white palette
    │   └── typography.ts          # Font weights/sizes
    ├── navigation/
    │   ├── RootNavigator.tsx      # Bottom tabs: Ask, Saved, Home, Community, Profile
    │   └── HomeStack.tsx          # Stack navigator: 14 screens under Home tab
    └── screens/
        ├── HomeScreen.tsx         # Voice-first dashboard with animated mic
        ├── AskScreen.tsx          # AI assistant with voice input
        ├── VoiceScreen.tsx        # Voice chat interface (speech bubbles)
        ├── AgriMarketScreen.tsx   # Agriculture/market dashboard
        ├── MarketPricesScreen.tsx  # Live mandi prices with search
        ├── AlertsScreen.tsx       # Price alert CRUD
        ├── SchemesListScreen.tsx  # Government schemes with filters
        ├── SchemeDetailScreen.tsx  # Individual scheme details
        ├── KnowledgeDashboardScreen.tsx  # Courses + peer groups
        ├── SavingsNudgeScreen.tsx  # AI savings nudge with donut chart
        ├── EligibilityScreen.tsx  # Loan eligibility assessment
        ├── SyncStatusScreen.tsx   # Offline sync status per module
        ├── CommunityScreen.tsx    # Peer spaces + posts (tab)
        ├── ProfileScreen.tsx      # Settings, privacy toggles (tab)
        ├── SavedScreen.tsx        # Bookmarked items (tab)
        ├── SavedDetailScreen.tsx  # Individual saved item view
        ├── ModuleScreen.tsx       # Generic module actions grid
        ├── ActionScreen.tsx       # Generic action placeholder
        ├── SplashScreen.tsx       # App loading animation
        └── SymptomCheckerScreen.tsx # Health symptom selector
```

---

## Navigation Architecture

### Bottom Tabs (RootNavigator)

```
┌─────────┬────────┬────────┬───────────┬─────────┐
│  Ask    │ Saved  │ Home   │ Community │ Profile │
└─────────┴────────┴────────┴───────────┴─────────┘
```

- **Ask** → `AskScreen` — AI assistant, voice input
- **Saved** → `SavedScreen` → `SavedDetailScreen`
- **Home** → `HomeStack` (14 nested screens)
- **Community** → `CommunityScreen` — spaces, posts
- **Profile** → `ProfileScreen` — settings, privacy

### HomeStack (Stack Navigator)

| Route Name | Screen | Params |
|------------|--------|--------|
| `HomeMain` | HomeScreen | — |
| `Module` | ModuleScreen | `{ title: string }` |
| `MarketPrices` | MarketPricesScreen | `{ moduleTitle?: string }` |
| `SchemesList` | SchemesListScreen | `{ moduleTitle?: string }` |
| `SchemeDetail` | SchemeDetailScreen | `{ schemeId: string }` |
| `SymptomChecker` | SymptomCheckerScreen | — |
| `Alerts` | AlertsScreen | — |
| `Voice` | VoiceScreen | — |
| `Action` | ActionScreen | `{ moduleTitle: string; actionTitle: string }` |
| `AgriMarket` | AgriMarketScreen | — |
| `KnowledgeDashboard` | KnowledgeDashboardScreen | — |
| `SavingsNudge` | SavingsNudgeScreen | — |
| `Eligibility` | EligibilityScreen | — |
| `SyncStatus` | SyncStatusScreen | — |

Type-safe params are defined in `HomeStackParamList` (see `HomeStack.tsx`).

---

## Theme System

### Colors (`src/theme/colors.ts`)

| Token | Value | Usage |
|-------|-------|-------|
| `primary` | `#4A90D9` | Mic button, accents, active states |
| `primaryDark` | `#2C6CB0` | Headings, pressed states |
| `primaryTint` | `rgba(74,144,217,0.12)` | Light backgrounds, badges |
| `success` | `#22C55E` | Verified, positive states |
| `warn` | `#F59E0B` | Warnings, alerts |
| `danger` | `#EF4444` | High-risk, errors |
| `ink` | `#1A1A2E` | Primary text |
| `muted` | `#6B7280` | Secondary text, icons |
| `bg` | `#F5F7FA` | Screen background |
| `card` | `#FFFFFF` | Card surface |
| `earth` | `#8B5E3C` | Agriculture accent |

Design follows a **blue/white voice-first** interface matching the Figma reference mockups.

---

## API Integration Layer

### Environment Config (`src/config/env.ts`)

```typescript
export const ENV = {
  API_BASE_URL: process.env.EXPO_PUBLIC_API_URL ?? `http://${LOCALHOST}:3000`,
  DEMO_USER_ID: process.env.EXPO_PUBLIC_DEMO_USER_ID ?? 'demo-user',
  REQUEST_TIMEOUT: 15_000,
  DEBUG_API: __DEV__,
};
```

- Android emulator uses `10.0.2.2` to reach host machine.
- iOS/web uses `localhost`.
- Override with `EXPO_PUBLIC_API_URL` env var for production.

### Core Client (`src/services/api.ts`)

All API calls go through a single `request()` function that:
1. Prepends `ENV.API_BASE_URL`
2. Sets `Content-Type: application/json`
3. Sets `X-User-Id: {ENV.DEMO_USER_ID}` header
4. Applies 15-second timeout via AbortController
5. Parses JSON response
6. Throws typed `ApiError` on non-2xx status

### Domain API Namespaces

```typescript
import {
  marketApi,      // getPrices, getPriceTrend, getMandis, getMandiPrices
  alertsApi,      // getAlerts, createAlert, deleteAlert
  supplyChainApi, // searchListings, createListing, getMyListings, getListing, searchBuyers
  logisticsApi,   // getBargainingGroups, getLogisticsQuote, getTransportOptions
  precisionApi,   // analyzeSoil, analyzePestDisease, calculateCarbon, getWeatherAdvisory, getPractices, logPractice
  knowledgeApi,   // getCourses, getMyCourses, getPeerGroups, getRecommendations, getLearningProfile, getGovtCourses, getProgressSummary
  economicsApi,   // getProfile, updateProfile, getSchemes, getScheme, getNudges, checkEligibility, getInsurance, getSavings
  healthCheck,    // GET /health
} from '../services/api';
```

### Generic Data Hook (`src/hooks/useApi.ts`)

```typescript
function useApi<T>(
  fetcher: (signal: AbortSignal) => Promise<T>,
  deps: unknown[],
  skip?: boolean,
): { data: T | null; loading: boolean; error: ApiError | null; refresh: () => void }
```

- **Auto-fetches** on mount and when `deps` change
- **Cancels** in-flight requests on unmount or re-fetch
- **`skip`** prevents auto-fetch (e.g., when param is empty)
- **`refresh()`** manually re-triggers the fetch

### Domain Hooks (`src/hooks/useData.ts`)

| Hook | API Call | Skip Condition |
|------|----------|----------------|
| `useMarketPrices(crop, state?, district?)` | `marketApi.getPrices` | `!crop` |
| `useMandis(state?)` | `marketApi.getMandis` | — |
| `usePriceAlerts()` | `alertsApi.getAlerts` | — |
| `useSchemes(category?, state?)` | `economicsApi.getSchemes` | — |
| `useSchemeDetail(id)` | `economicsApi.getScheme` | `!id` |
| `useNudges(limit)` | `economicsApi.getNudges` | — |
| `useCourses(language?, difficulty?)` | `knowledgeApi.getCourses` | — |
| `usePeerGroups()` | `knowledgeApi.getPeerGroups` | — |
| `useRecommendations()` | `knowledgeApi.getRecommendations` | — |
| `useLearningProfile()` | `knowledgeApi.getLearningProfile` | — |
| `useWeatherAdvisory(lat, lon, crop?)` | `precisionApi.getWeatherAdvisory` | `!lat \|\| !lon` |
| `useHealthCheck()` | `healthCheck()` | — |

---

## Shared UI Components (`src/components/ui.tsx`)

| Component | Props | Description |
|-----------|-------|-------------|
| `LoadingView` | `message?: string` | Centered spinner with label |
| `ErrorView` | `message?: string; onRetry?: () => void` | Cloud-offline icon + retry button |
| `EmptyView` | `icon?, title?, subtitle?` | Empty state placeholder |
| `SyncPill` | `synced?: boolean` | Green "LIVE" or gray "OFFLINE" pill |

---

## Screen-by-Screen Breakdown

### HomeScreen
- **Voice-first dashboard** — animated microphone button with waveform bars
- Module tiles: Agriculture, Knowledge, Economics, Health, Infrastructure
- Taps navigate to respective dashboard screens
- Uses `useHealthCheck()` to show backend connectivity

### VoiceScreen
- Chat-style interface with speech bubbles (user Hindi, AI English)
- Animated waveform when "listening"
- Camera CTA for image-based queries
- Keyboard-avoiding layout for text input fallback

### AgriMarketScreen
- Map placeholder header
- Buyer stats cards
- Crop price mini-charts (uses `useMarketPrices("wheat")` and `useMarketPrices("rice")`)
- "Collect to Bargain" collective bargaining CTA

### MarketPricesScreen
- Search input for crop name
- Average price display with timestamp
- Price list per mandi
- Uses `useMarketPrices(crop)` with debounced search

### AlertsScreen
- Create new alert (crop name input)
- List existing alerts with delete action
- Uses `usePriceAlerts()`, `alertsApi.createAlert()`, `alertsApi.deleteAlert()`

### SchemesListScreen
- Filter chips: All, Loan, Insurance, Subsidy
- Text search within results
- Navigates to `SchemeDetail` on tap
- Uses `useSchemes(category)`

### SchemeDetailScreen
- Full scheme info: name, benefit, eligibility, provider, type
- TTS "Listen" button placeholder
- Save/bookmark toggle
- Uses `useSchemeDetail(schemeId)`

### KnowledgeDashboardScreen
- Course progress cards with percentage bars
- Peer learning group list with member counts
- Audio stream with LIVE badge
- Uses `useCourses()`, `usePeerGroups()`, `useLearningProfile()`

### SavingsNudgeScreen
- Donut chart: Expected Harvest vs. Current Savings
- Hindi AI nudge message
- Action buttons for savings plan
- Uses `useNudges(5)`

### EligibilityScreen
- User farming data display (name, capacity, loan amount)
- AI eligibility score (gauge visualization)
- Pre-approval status card
- Static demo data (backend integration ready)

### SyncStatusScreen
- Per-module sync status (cached/compressed sizes)
- Filter chips: Agriculture, Economics, Health
- "Sync Now" button
- Uses `useHealthCheck()` for connectivity indicator

### CommunityScreen
- Live voice spaces with listener counts
- Community posts feed with tags
- Uses `usePeerGroups()` with fallback data

### ProfileScreen
- User profile card (avatar, name, region)
- Toggle switches: low data mode, offline cache, TTS
- Privacy toggles: location, farming, health, learning sharing

---

## Adding a New Screen

1. **Create screen file** in `src/screens/NewScreen.tsx`
2. **Add route** to `HomeStackParamList` type in `HomeStack.tsx`
3. **Register screen** in `HomeStack` navigator:
   ```tsx
   <Stack.Screen name="NewScreen" component={NewScreen} />
   ```
4. **Navigate** from any screen:
   ```tsx
   const nav = useNavigation<any>();
   nav.navigate('NewScreen', { /* params */ });
   ```
5. **Add data hook** (if backend-connected) in `useData.ts`:
   ```tsx
   export function useNewData(param: string) {
     return useApi(
       () => someApi.getData(param),
       [param],
       !param,
     );
   }
   ```

---

## Offline-First Patterns

The app is designed for low-bandwidth rural deployment:

- **Fallback data**: Screens like `CommunityScreen` include `FALLBACK_SPACES` arrays shown when API fails
- **SyncPill**: Every data screen shows LIVE/OFFLINE badge
- **Error recovery**: `ErrorView` has retry button that re-triggers the hook
- **Timeout**: 15-second timeout prevents indefinite loading
- **Demo user**: `X-User-Id: demo-user` header allows unauthenticated access

### Future Offline Enhancements
- AsyncStorage caching layer in `useApi`
- Background sync queue for POST/PUT operations
- SQLite local database for critical data
- Progressive content download

---

## TypeScript

- **0 errors** across all files
- Navigation params are typed via `HomeStackParamList`
- API responses typed via interfaces in `api.ts`
- Hook return types inferred from `useApi<T>` generic

Run type check:
```bash
cd RuralAi && npx tsc --noEmit
```

---

## Dependencies

### Production
| Package | Purpose |
|---------|---------|
| `expo` | Build, dev server, OTA updates |
| `react` / `react-native` | UI framework |
| `@react-navigation/native` | Navigation core |
| `@react-navigation/native-stack` | Stack navigator |
| `@react-navigation/bottom-tabs` | Tab navigator |
| `react-native-safe-area-context` | Safe area handling |
| `react-native-screens` | Native screen optimization |
| `react-native-web` | Web platform support |
| `@expo/vector-icons` | Icon library (Ionicons) |
| `expo-status-bar` | Status bar control |

### Dev
| Package | Purpose |
|---------|---------|
| `@types/react` | React TS definitions |
| `typescript` | TS compiler |
