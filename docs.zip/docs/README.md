# Project Overview

## Architecture

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         AWS Cloud (ap-south-1)                          │
│                                                                          │
│  ┌─────────────┐    ┌──────────────────────────────────────────────┐     │
│  │   Cognito    │    │         ECS Fargate Cluster                  │     │
│  │  User Pool   │    │  ┌────────────────────────────────────────┐  │     │
│  └──────┬───────┘    │  │  Fastify API (Node 20)                 │  │     │
│         │            │  │  /health                               │  │     │
│         │            │  │  /knowledge/*  (23 endpoints)          │  │     │
│  ┌──────┴───────┐    │  │  /agriculture/* (32 endpoints)         │  │     │
│  │     ALB      │───>│  │  /agriculture/precision/* (7 endpts)   │  │     │
│  │  (port 80)   │    │  │  /economics/*  (10 endpoints)          │  │     │
│  └──────────────┘    │  └─────────┬──────────────────────────────┘  │     │
│                      └────────────┼─────────────────────────────────┘     │
│                                   │                                       │
│         ┌─────────────────────────┼─────────────────────────┐             │
│         │                         │                         │             │
│   ┌─────▼──────┐   ┌─────────────▼──────────┐   ┌──────────▼──────┐     │
│   │  DynamoDB   │   │     S3 (3 buckets)     │   │  SNS (4 topics) │     │
│   │ (18 tables) │   │  content, media, health│   │  alerts, notifs │     │
│   └─────────────┘   └───────────────────────┘   └─────────────────┘     │
│                                                                          │
│   ┌──────────────────────────────────────────┐                           │
│   │  AI Services                              │                           │
│   │  Bedrock (Claude 3 Haiku)                │                           │
│   │  Polly (TTS - Kajal neural voice)        │                           │
│   │  Translate (multi-language)              │                           │
│   └──────────────────────────────────────────┘                           │
└──────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────┐
│                          Mobile Client                                    │
│  React Native (Expo SDK 54) + TypeScript                                 │
│  14 screens │ Voice-first UI │ Offline-capable                           │
└──────────────────────────────────────────────────────────────────────────┘
```

## Project Structure

```
aws-ai4bharat-hackathon/
├── README.md                          # Root readme with quick links
├── docs/                              # All documentation
│   ├── README.md                      # This file — architecture overview
│   ├── aws-infrastructure.md          # AWS resources (DynamoDB, S3, etc.)
│   ├── backend-api.md                 # 72 endpoint API reference
│   ├── ci-cd-pipeline.md             # GitHub Actions, secrets, deploys
│   ├── deployment-guide.md           # Local / Docker / Production setup
│   └── frontend-guide.md            # React Native screens & navigation
│
├── backend/                           # Fastify Node.js API server
│   ├── Dockerfile                     # Multi-stage Node 20 Alpine
│   ├── package.json                   # v2.0.0 — 20 deps, 85 tests
│   ├── server.js                      # Entrypoint — Fastify app builder
│   ├── routes/                        # 4 route modules
│   │   ├── knowledge.js               #   23 endpoints
│   │   ├── agriculture.js             #   32 endpoints
│   │   ├── precision-agriculture.js   #   7 endpoints
│   │   └── economic-services.js       #   10 endpoints
│   ├── lambdas/                       # Business logic (ex-Lambda handlers)
│   │   ├── knowledge-api/             #   content, courses, enrollment, govt
│   │   ├── learning-path/             #   analytics, learning-profile, recs
│   │   ├── peer-grouping/             #   clustering, digilocker, groups
│   │   ├── market-data/               #   prices, alerts
│   │   ├── supply-chain-api/          #   listings, buyers
│   │   ├── logistics/                 #   transport, collective-bargaining
│   │   ├── precision-agriculture/     #   advisory, carbon, pest, weather
│   │   └── economic-services/         #   eligibility, insurance, nudges, etc.
│   ├── middleware/
│   │   ├── auth.js                    #   X-User-Id / Cognito JWT auth
│   │   └── error-handler.js           #   Global error handler
│   ├── utils/
│   │   ├── constants.js               #   Polly voices, Bedrock prompts
│   │   ├── db.js                      #   DynamoDB + Postgres helpers
│   │   └── response.js               #   Standard response wrapper
│   ├── tests/unit/                    #   20 test files, 85 tests
│   └── db/                            #   Schema files
│       ├── agriculture-schema.sql
│       ├── knowledge-schema.sql
│       └── dynamo-tables.json
│
├── RuralAi/                           # React Native Expo frontend
│   ├── src/
│   │   ├── screens/           (14)    #   All app screens
│   │   ├── navigation/        (4)     #   Stack + Tab navigators
│   │   ├── hooks/             (2)     #   useApi, useData
│   │   ├── services/          (1)     #   api.ts — backend client
│   │   ├── config/            (1)     #   env.ts
│   │   ├── components/        (1)     #   ui.tsx — shared components
│   │   └── theme/             (2)     #   colors, typography
│   └── package.json
│
├── infra/                             # Infrastructure as Code
│   ├── ecs.yaml                       #   CloudFormation — ECS Fargate stack
│   ├── template.yaml                  #   SAM template (Reqs 5-8 Lambdas)
│   ├── provision-aws.sh              #   Idempotent resource provisioning
│   ├── deploy.sh                      #   One-click deploy script
│   └── teardown.sh                    #   Stack teardown script
│
├── rohit/                             # Feature branches (Reqs 9-11)
│   ├── feature1/                      #   Open Data Standards (Req 11)
│   ├── feature2/                      #   Community Platform (Req 10)
│   └── feature3/                      #   Health Services (Req 9)
│
├── .github/workflows/
│   ├── ci.yml                         #   PR test runner
│   └── deploy.yml                     #   Auto-deploy to ECS on push to main
│
├── docker-compose.yml                 #   Local + AWS dev environments
├── .env                               #   AWS resource references
├── design.md                          #   Design decisions
└── requirements.md                    #   Original hackathon requirements
```

## Requirements Coverage

| Req # | Feature | Status | Backend | Frontend |
|-------|---------|--------|---------|----------|
| 5 | Knowledge & Learning Pathways | Done | 23 endpoints | KnowledgeDashboardScreen |
| 6 | Supply Chain & Market Access | Done | 32 endpoints | AgriMarketScreen, MarketPricesScreen |
| 7 | Precision Agriculture | Done | 7 endpoints | HomeScreen (advisory cards) |
| 8 | Economic Services | Done | 10 endpoints | SchemesListScreen, SavingsNudgeScreen, EligibilityScreen |
| 9 | Health Services | Done | rohit/feature3 | SymptomCheckerScreen |
| 10 | Community Platform | Done | rohit/feature2 | CommunityScreen, VoiceScreen |
| 11 | Open Data Standards | Done | rohit/feature1 | SyncStatusScreen |

## Key Design Decisions

1. **Fastify over Express** — 2-3x faster, built-in schema validation, TypeScript-friendly logging (Pino)
2. **DynamoDB over Aurora** — $0 idle cost, no connection pooling issues, simpler for key-value patterns
3. **ECS Fargate over Lambda** — Single deployment unit, WebSocket support, lower cold-start latency
4. **Mono-container** — All 72 endpoints in one container (simpler for <=100 RPS hackathon scale)
5. **Voice-first UI** — Blue theme, large tap targets, VoiceScreen as primary interaction mode
6. **Cost optimization** — 256 CPU / 512 MB Fargate, auto-scales 1-3, DynamoDB on-demand (~$30/mo total)
