# Deployment Guide

## Environments

| Environment | Method | Description |
|-------------|--------|-------------|
| **Local (bare)** | `npm run dev` | Node.js directly, no Docker |
| **Local (Docker)** | `docker compose --profile local up` | Full local stack with DynamoDB-local + Postgres |
| **Dev (AWS)** | `docker compose up` or CI/CD | Uses AWS DynamoDB, S3, SNS |
| **Production (ECS)** | CI/CD or `./infra/deploy.sh` | Full AWS Fargate deployment |

---

## 1. Local Development (No Docker)

### Prerequisites
- Node.js >= 20
- npm

### Steps

```bash
cd backend
npm install
npm run dev     # Starts with --watch for auto-reload
```

Server starts at `http://localhost:3000`. Uses mock data and `DIGILOCKER_USE_MOCK=true`.

### Running Tests

```bash
npm test                    # All 85 tests with coverage
npm run test:unit           # Unit tests only
npm test -- --watch         # Watch mode
```

---

## 2. Docker (Local Services)

Runs the backend alongside local PostgreSQL and DynamoDB containers.

```bash
# From project root
docker compose --profile local up -d

# Check status
docker compose ps

# View logs
docker compose logs -f app

# Stop
docker compose --profile local down
```

**Services:**
| Service | Port | Image |
|---------|------|-------|
| `app` | 3000 | `./backend/Dockerfile` |
| `postgres` | 5432 | `postgres:15-alpine` |
| `dynamodb-local` | 8000 | `amazon/dynamodb-local` |

---

## 3. Docker (AWS Services)

Uses AWS managed DynamoDB/S3/SNS instead of local containers. Requires `.env` with AWS resource references.

```bash
# From project root (ensure .env exists)
docker compose up -d

# Stop
docker compose down
```

---

## 4. Production (AWS ECS Fargate)

### Architecture

```
Internet
    │
    ▼
┌────────────┐     ┌─────────────────────────────┐
│    ALB     │────>│  ECS Fargate Task            │
│  port 80   │     │  256 CPU / 512 MB            │
│            │     │  rural-platform-backend:tag   │
└────────────┘     │  Port 3000                   │
                   └──────┬──────────────────────┘
                          │
              ┌───────────┼───────────┐
              ▼           ▼           ▼
          DynamoDB       S3         SNS
         18 tables    3 buckets   4 topics
```

### AWS Resources

| Resource | Name/ID |
|----------|---------|
| **Account** | 111418871333 |
| **Region** | ap-south-1 (Mumbai) |
| **VPC** | vpc-0caeb0d2ebe85e669 (default) |
| **Subnets** | subnet-00102fd8f02546f3f (1a), subnet-0de9101cc6a6f388f (1b), subnet-0372f717ad5bf8f18 (1c) |
| **ECS Cluster** | rural-dev |
| **ECS Service** | rural-svc-dev (1 task, auto-scales to 3) |
| **ALB** | rural-alb-dev |
| **ALB URL** | `http://rural-alb-dev-2139845854.ap-south-1.elb.amazonaws.com` |
| **ECR** | 111418871333.dkr.ecr.ap-south-1.amazonaws.com/rural-platform-backend |
| **CloudFormation** | rural-platform-ecs-dev |
| **Cognito** | ap-south-1_5eGqm0JvM |

### Deploy via Script

```bash
./infra/deploy.sh dev
```

This will:
1. Build Docker image from `./backend/`
2. Tag with git SHA + timestamp
3. Push to ECR
4. Run `aws cloudformation deploy` with `infra/ecs.yaml`
5. Wait for service stability
6. Print API URL

### Deploy via GitHub Actions

Push to `main` branch with changes in `backend/**` or `infra/ecs.yaml`.
See [CI/CD Pipeline](ci-cd-pipeline.md) for details.

### Manual CloudFormation Deploy

```bash
# Build and push image first
IMAGE_TAG="$(git rev-parse --short HEAD)-$(date +%s)"
ECR_URI="111418871333.dkr.ecr.ap-south-1.amazonaws.com/rural-platform-backend"

aws ecr get-login-password --region ap-south-1 | \
  docker login --username AWS --password-stdin "$ECR_URI"

docker build -t "${ECR_URI}:${IMAGE_TAG}" ./backend
docker push "${ECR_URI}:${IMAGE_TAG}"

# Deploy stack
aws cloudformation deploy \
  --region ap-south-1 \
  --template-file infra/ecs.yaml \
  --stack-name rural-platform-ecs-dev \
  --capabilities CAPABILITY_NAMED_IAM \
  --no-fail-on-empty-changeset \
  --parameter-overrides \
    Stage=dev \
    VpcId=vpc-0caeb0d2ebe85e669 \
    SubnetIds="subnet-00102fd8f02546f3f,subnet-0de9101cc6a6f388f,subnet-0372f717ad5bf8f18" \
    ImageUri="${ECR_URI}:${IMAGE_TAG}" \
    CognitoUserPoolId=ap-south-1_5eGqm0JvM \
    CognitoAppClientId=7037npivotg1kmnf5pm0cd1und \
    ContentBucket=rural-platform-content-dev-111418871333 \
    CommunityMediaBucket=rural-community-media-dev-111418871333 \
    HealthImagingBucket=rural-health-imaging-dev-111418871333 \
    PriceAlertSnsTopic=arn:aws:sns:ap-south-1:111418871333:rural-price-alerts-dev \
    FinancialNotificationsTopic=arn:aws:sns:ap-south-1:111418871333:rural-financial-notifications-dev \
    LearningNotificationsTopic=arn:aws:sns:ap-south-1:111418871333:rural-learning-notifications-dev \
    CommunityNotificationsTopic=arn:aws:sns:ap-south-1:111418871333:rural-community-notifications-dev
```

---

## 5. Provision AWS Resources

The shared AWS resources (DynamoDB, S3, SNS, Cognito) are provisioned separately from the ECS stack:

```bash
# First time only — creates 18 tables, 3 buckets, 4 topics, 1 Cognito pool
./infra/provision-aws.sh

# Generates .env with all resource references
```

This is **idempotent** — safe to run multiple times. Existing resources are skipped.

---

## 6. Teardown

### Remove ECS stack only (keeps data resources)

```bash
./infra/teardown.sh dev
```

This deletes: ECS cluster, ALB, security groups, IAM roles, CloudWatch logs.
This keeps: DynamoDB tables, S3 buckets, SNS topics, Cognito pool.

### Full cleanup (remove everything)

```bash
# Delete ECS stack
./infra/teardown.sh dev

# Delete DynamoDB tables
aws dynamodb list-tables --query 'TableNames[?ends_with(@,`-dev`)]' --output text | \
  tr '\t' '\n' | xargs -I{} aws dynamodb delete-table --table-name {}

# Empty and delete S3 buckets
for b in rural-platform-content-dev-111418871333 \
         rural-community-media-dev-111418871333 \
         rural-health-imaging-dev-111418871333; do
  aws s3 rm "s3://$b" --recursive
  aws s3api delete-bucket --bucket "$b"
done

# Delete SNS topics
aws sns list-topics --query 'Topics[?contains(TopicArn,`-dev`)].TopicArn' --output text | \
  tr '\t' '\n' | xargs -I{} aws sns delete-topic --topic-arn {}

# Delete Cognito
aws cognito-idp delete-user-pool --user-pool-id ap-south-1_5eGqm0JvM

# Delete ECR
aws ecr delete-repository --repository-name rural-platform-backend --force

# Delete IAM user
aws iam delete-user-policy --user-name github-actions-deployer --policy-name deploy-policy
aws iam list-access-keys --user-name github-actions-deployer --query 'AccessKeyMetadata[*].AccessKeyId' --output text | \
  xargs -I{} aws iam delete-access-key --user-name github-actions-deployer --access-key-id {}
aws iam delete-user --user-name github-actions-deployer
```

---

## Cost Estimate (Monthly)

| Service | Configuration | Est. Cost |
|---------|--------------|-----------|
| ECS Fargate | 0.25 vCPU, 0.5 GB, 1 task (24/7) | ~$9 |
| ALB | 1 LCU average | ~$18 |
| DynamoDB | On-demand, 18 tables, low traffic | ~$1 |
| ECR | < 1 GB stored (5 image limit) | ~$0.10 |
| S3 | 3 buckets, minimal storage | ~$0.50 |
| SNS | 4 topics, low volume | ~$0.10 |
| Cognito | < 50,000 MAU (free tier) | $0 |
| CloudWatch | 14-day retention, low volume | ~$0.50 |
| **Total** | | **~$30/month** |

Auto-scaling can increase costs if traffic spikes (max 3 tasks = ~$27 ECS), but the $100 budget provides ample headroom.

---

## Environment Variables

The ECS task receives these environment variables via CloudFormation:

| Variable | Source | Description |
|----------|--------|-------------|
| `NODE_ENV` | Hardcoded `production` | Runtime mode |
| `PORT` | `3000` | Server port |
| `AWS_REGION` | Stack region | AWS SDK region |
| `STAGE` | Parameter | dev/staging/prod |
| `BEDROCK_MODEL_ID` | Parameter | Claude 3 Haiku model |
| `COGNITO_USER_POOL_ID` | Parameter | Auth pool |
| `COGNITO_APP_CLIENT_ID` | Parameter | Auth client |
| `CONTENT_BUCKET` | Parameter | S3 course content |
| `COMMUNITY_MEDIA_BUCKET` | Parameter | S3 community media |
| `HEALTH_IMAGING_BUCKET` | Parameter | S3 health images |
| `PRICE_ALERT_SNS_TOPIC` | Parameter | SNS price alerts |
| `FINANCIAL_NOTIFICATIONS_TOPIC_ARN` | Parameter | SNS financial |
| `LEARNING_NOTIFICATIONS_TOPIC_ARN` | Parameter | SNS learning |
| `COMMUNITY_NOTIFICATIONS_TOPIC_ARN` | Parameter | SNS community |
| `USER_LEARNING_PROFILE_TABLE` | Derived | DynamoDB table |
| `PEER_GROUPS_TABLE` | Derived | DynamoDB table |
| ... (18 total DynamoDB tables) | Derived | `TableName-{stage}` |
| `PG_HOST`, `PG_PASSWORD` | Parameter (optional) | PostgreSQL (Aurora) |
| `DIGILOCKER_USE_MOCK` | `true` | Skip real DigiLocker API |
