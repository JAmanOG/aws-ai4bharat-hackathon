# AWS Infrastructure — Unified Provisioning Guide

## Overview

The Rural Ecosystem Platform spans **4 independent feature sets** (Requirements 5–11), each originally defined in its own SAM template. To eliminate redundancy (each template created its own Cognito pool + Aurora cluster), we unified all AWS resource provisioning into a **single CLI-driven script** that creates shared infrastructure.

---

## Architecture Map

```
┌─────────────────────────────────────────────────────────────────┐
│                    AWS Account: 111418871333                    │
│                    Region:     ap-south-1                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────┐   ┌──────────────┐   ┌───────────────┐        │
│  │  Cognito     │   │  S3 Buckets  │   │  SNS Topics   │        │
│  │  (1 shared)  │   │  (3)         │   │  (4)          │        │
│  └──────┬───────┘   └──────┬───────┘   └───────┬───────┘        │
│         │                  │                   │                │
│  ┌──────┴──────────────────┴───────────────────┴────────┐       │
│  │                  DynamoDB (18 tables)                │       │
│  │                                                      │       │
│  │  Reqs 5-8      Req 9        Req 10       Req 11      │       │
│  │  (11 tables)   (2 tables)   (4 tables)   (1 table)   │       │
│  └──────────────────────────────────────────────────────┘       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Source Templates Analyzed

| Template | Location | Scope | Requirements |
|----------|----------|-------|-------------|
| Main platform | `infra/template.yaml` | Knowledge, Agriculture, Economics, Precision Ag | Reqs 5, 6, 7, 8 |
| Feature 1 (Rohit) | `rohit/feature1/infra/template.yaml` | Open Data Standards & Interoperability | Req 11 |
| Feature 2 (Rohit) | `rohit/feature2/infra/template.yaml` | Community Platform — Voice Rooms, Business, Government | Req 10 |
| Feature 3 (Rohit) | `rohit/feature3/infra/template.yaml` | Health Services — Symptom Checker, Imaging, Providers | Req 9 |
| ECS template | `infra/ecs.yaml` | Production Fargate deployment (container-based) | All |

---

## Redundancy Eliminated

Each of Rohit's 3 templates independently created:
- Its own **Cognito User Pool** (3 separate pools)
- Its own **Aurora Serverless v2 cluster** (3 separate clusters)

**After unification:**
- **1 shared Cognito User Pool** (`rural-platform-users-dev`, ID: `ap-south-1_5eGqm0JvM`)
- **1 shared App Client** (ID: `7037npivotg1kmnf5pm0cd1und`)
- Aurora clusters are deferred to production deployment (not needed for dev with DynamoDB-only approach)

---

## Resources Created

### DynamoDB Tables (18)

#### Reqs 5–8: Knowledge / Agriculture / Economics (from `infra/template.yaml`)

| # | Table Name | Partition Key | Sort Key | TTL | GSI |
|---|-----------|--------------|----------|-----|-----|
| 1 | `UserLearningProfile-dev` | `userId` (S) | — | — | — |
| 2 | `PeerGroups-dev` | `groupId` (S) | — | — | — |
| 3 | `LearningRecommendations-dev` | `userId` (S) | `generatedAt` (S) | ✅ `ttl` | — |
| 4 | `ContentInteractions-dev` | `userId` (S) | `interactionId` (S) | — | — |
| 5 | `FarmerProfiles-dev` | `farmerId` (S) | — | — | — |
| 6 | `PriceAlerts-dev` | `userId` (S) | `alertId` (S) | — | — |
| 7 | `PriceWatch-dev` | `cropType` (S) | `timestamp` (S) | ✅ `ttl` | — |
| 8 | `FarmPracticeLogs-dev` | `userId` (S) | `loggedAt` (S) | — | — |
| 9 | `EconomicProfiles-dev` | `userId` (S) | — | — | — |
| 10 | `InsuranceClaims-dev` | `userId` (S) | `claimId` (S) | — | — |
| 11 | `FinancialNudges-dev` | `userId` (S) | `generatedAt` (S) | — | — |

#### Req 9: Health Services (from `rohit/feature3/infra/template.yaml`)

| # | Table Name | Partition Key | Sort Key | TTL | GSI |
|---|-----------|--------------|----------|-----|-----|
| 12 | `HealthArticles-dev` | `articleId` (S) | — | ✅ `ttl` | `ByTopic` (topic → ALL) |
| 13 | `SymptomLogs-dev` | `userId` (S) | `checkedAt` (S) | ✅ `ttl` | — |

#### Req 10: Community Platform (from `rohit/feature2/infra/template.yaml`)

| # | Table Name | Partition Key | Sort Key | TTL | GSI |
|---|-----------|--------------|----------|-----|-----|
| 14 | `VoiceRooms-dev` | `roomId` (S) | — | — | `ByStatus` (status + createdAt → ALL) |
| 15 | `VoiceRoomParticipants-dev` | `roomId` (S) | `userId` (S) | — | — |
| 16 | `ChatMessages-dev` | `roomId` (S) | `messageId` (S) | — | — |
| 17 | `WebSocketConnections-dev` | `connectionId` (S) | — | ✅ `ttl` | — |

#### Req 11: Open Data Export (from `rohit/feature1/infra/template.yaml`)

| # | Table Name | Partition Key | Sort Key | TTL | GSI |
|---|-----------|--------------|----------|-----|-----|
| 18 | `ExportAudit-dev` | `userId` (S) | `exportedAt` (S) | ✅ `ttl` | — |

### S3 Buckets (3)

| Bucket | Source | Purpose | Special Config |
|--------|--------|---------|---------------|
| `rural-platform-content-dev-111418871333` | `infra/template.yaml` | Learning content, course media | CORS (GET) |
| `rural-community-media-dev-111418871333` | `rohit/feature2` | Community posts, voice recordings | CORS (GET, PUT) |
| `rural-health-imaging-dev-111418871333` | `rohit/feature3` | Medical imaging uploads | CORS (GET, PUT), 30-day expiry lifecycle |

### SNS Topics (4)

| Topic | ARN | Source |
|-------|-----|--------|
| `rural-price-alerts-dev` | `arn:aws:sns:ap-south-1:111418871333:rural-price-alerts-dev` | `infra/template.yaml` |
| `rural-financial-notifications-dev` | `arn:aws:sns:ap-south-1:111418871333:rural-financial-notifications-dev` | `infra/template.yaml` |
| `rural-learning-notifications-dev` | `arn:aws:sns:ap-south-1:111418871333:rural-learning-notifications-dev` | `infra/template.yaml` |
| `rural-community-notifications-dev` | `arn:aws:sns:ap-south-1:111418871333:rural-community-notifications-dev` | `rohit/feature2` |

### Cognito (1 shared pool)

| Resource | Value |
|----------|-------|
| User Pool Name | `rural-platform-users-dev` |
| User Pool ID | `ap-south-1_5eGqm0JvM` |
| App Client Name | `rural-platform-app-dev` |
| App Client ID | `7037npivotg1kmnf5pm0cd1und` |
| Username Attribute | `phone_number` |
| Auth Flows | `ALLOW_USER_SRP_AUTH`, `ALLOW_REFRESH_TOKEN_AUTH` |

---

## Files Created / Modified

| File | Action | Purpose |
|------|--------|---------|
| `infra/provision-aws.sh` | **Created** | Idempotent bash script that provisions all 26 resources via AWS CLI |
| `.env` | **Created** | All resource ARNs, table names, bucket names, Cognito IDs for backend consumption |
| `docker-compose.yml` | **Modified** | Postgres & DynamoDB-local moved behind `--profile local`; default mode reads from `.env` and uses real AWS services |

---

## How to Use

### Provision All Resources (first time or new account)

```bash
# Default stage: dev, region: ap-south-1
bash infra/provision-aws.sh

# Or specify stage
STAGE=prod bash infra/provision-aws.sh
```

The script is **idempotent** — it checks if each resource exists before creating it, so it's safe to re-run.

### Start the Backend

```bash
# Using AWS managed services (reads .env)
docker compose up -d

# Or with local Postgres + DynamoDB-local
docker compose --profile local up -d
```

### Environment Variables

The `.env` file at project root is auto-generated by the provisioning script and consumed by `docker-compose.yml`. Key variables:

```
AWS_REGION=ap-south-1
COGNITO_USER_POOL_ID=ap-south-1_5eGqm0JvM
CONTENT_BUCKET=rural-platform-content-dev-111418871333
PRICE_ALERT_SNS_TOPIC=arn:aws:sns:ap-south-1:111418871333:rural-price-alerts-dev
USER_LEARNING_PROFILE_TABLE=UserLearningProfile-dev
... (18 DynamoDB table names, 3 bucket names, 4 SNS ARNs)
```

---

## Mapping: Template Resources → CLI Resources

### What was NOT provisioned via CLI (deferred to production)

| Resource | Reason |
|----------|--------|
| **Aurora Serverless v2** | All 3 templates define Aurora clusters. Skipped for dev — the backend Lambda handlers work with DynamoDB for most operations. Aurora is needed only for `rohit/feature2` (businesses, government, community posts) and `rohit/feature3` (health directory). Deploy via SAM for production. |
| **API Gateway** | Created automatically by SAM deploy, not needed for local dev (Fastify serves all routes directly). |
| **Lambda Functions** | Created automatically by SAM deploy. For dev, the Fastify container serves the same handler code. |
| **WebSocket API** | Feature 2's voice room signaling. Requires SAM deploy with proper integrations. |

### Production Deployment Path

For production, use SAM to deploy each template individually. The DynamoDB tables, S3 buckets, SNS topics, and Cognito pool created by the CLI script will be **reused** (tables are referenced by name in the SAM templates via `!Sub` with the same `${Stage}` suffix pattern).

```bash
# Deploy main platform (Reqs 5-8)
cd infra && sam deploy --guided --stack-name rural-platform-dev

# Deploy Rohit's features
cd rohit/feature1/infra && sam deploy --guided --stack-name rural-opendata-dev
cd rohit/feature2/infra && sam deploy --guided --stack-name rural-community-dev
cd rohit/feature3/infra && sam deploy --guided --stack-name rural-health-dev
```

> **Note:** For SAM deploy, the Cognito pools and DynamoDB tables in each template should be changed to `AWS::CloudFormation::Import` or parameter-based references to avoid recreating them. The CLI script handles the dev environment; SAM handles production.

---

## Billing Mode

All DynamoDB tables use **PAY_PER_REQUEST** (on-demand) billing — no provisioned capacity, no cost when idle. This is ideal for a hackathon/dev environment.

---

## Cleanup

To delete all resources:

```bash
# DynamoDB
aws dynamodb list-tables --query 'TableNames[?ends_with(@,`-dev`)]' --output text | \
  tr '\t' '\n' | xargs -I{} aws dynamodb delete-table --table-name {}

# S3 (must empty first)
for b in rural-platform-content-dev-111418871333 rural-community-media-dev-111418871333 rural-health-imaging-dev-111418871333; do
  aws s3 rm "s3://$b" --recursive
  aws s3api delete-bucket --bucket "$b"
done

# SNS
aws sns list-topics --query 'Topics[?contains(TopicArn,`-dev`)].TopicArn' --output text | \
  tr '\t' '\n' | xargs -I{} aws sns delete-topic --topic-arn {}

# Cognito
aws cognito-idp delete-user-pool --user-pool-id ap-south-1_5eGqm0JvM
```

---

## CI/CD & Production Deployment

### Architecture

```
GitHub (main branch)
    │
    ▼  push event
┌─────────────────────────────────┐
│  GitHub Actions (.github/workflows/deploy.yml)  │
│                                                  │
│  1. npm test (85 tests)                          │
│  2. docker build → ECR push                      │
│  3. cloudformation deploy (infra/ecs.yaml)       │
│  4. health check                                 │
└──────────────┬──────────────────┘
               ▼
┌──────────────────────────────────┐
│  AWS ECS Fargate (rural-dev)     │
│  • 1 task (256 CPU / 512 MB)     │
│  • Auto-scales 1→3 at 70% CPU   │
│  • ALB: rural-alb-dev            │
└──────────────────────────────────┘
```

### Live Endpoints

| Resource | Value |
|----------|-------|
| **API URL** | `http://rural-alb-dev-2139845854.ap-south-1.elb.amazonaws.com` |
| **Health Check** | `GET /health` → `{"status":"healthy","version":"2.0.0"}` |
| **ECS Cluster** | `rural-dev` |
| **ECS Service** | `rural-svc-dev` |
| **ECR Repo** | `111418871333.dkr.ecr.ap-south-1.amazonaws.com/rural-platform-backend` |
| **CloudFormation Stack** | `rural-platform-ecs-dev` |

### GitHub Secrets Required

Add these to **Settings → Secrets and variables → Actions** in your GitHub repo:

| Secret | Value |
|--------|-------|
| `AWS_ACCESS_KEY_ID` | `AKIART4IVBYSZ7NSQYUZ` |
| `AWS_SECRET_ACCESS_KEY` | *(see deployment notes)* |
| `VPC_ID` | `vpc-0caeb0d2ebe85e669` |
| `SUBNET_IDS` | `subnet-00102fd8f02546f3f,subnet-0de9101cc6a6f388f,subnet-0372f717ad5bf8f18` |
| `COGNITO_USER_POOL_ID` | `ap-south-1_5eGqm0JvM` |
| `COGNITO_APP_CLIENT_ID` | `7037npivotg1kmnf5pm0cd1und` |
| `CONTENT_BUCKET` | `rural-platform-content-dev-111418871333` |
| `COMMUNITY_MEDIA_BUCKET` | `rural-community-media-dev-111418871333` |
| `HEALTH_IMAGING_BUCKET` | `rural-health-imaging-dev-111418871333` |
| `PRICE_ALERT_SNS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-price-alerts-dev` |
| `FINANCIAL_NOTIFICATIONS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-financial-notifications-dev` |
| `LEARNING_NOTIFICATIONS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-learning-notifications-dev` |
| `COMMUNITY_NOTIFICATIONS_TOPIC` | `arn:aws:sns:ap-south-1:111418871333:rural-community-notifications-dev` |

### Manual Deploy (Local)

```bash
./infra/deploy.sh dev      # Build, push, deploy
./infra/teardown.sh dev    # Tear down ECS stack (keeps DynamoDB/S3/SNS)
```

### Cost Estimate (Monthly)

| Service | Config | Est. Cost |
|---------|--------|-----------|
| ECS Fargate | 0.25 vCPU / 0.5 GB, 1 task | ~$9 |
| ALB | 1 LCU avg | ~$18 |
| DynamoDB | PAY_PER_REQUEST, 18 tables | ~$1 |
| ECR | <1 GB stored | ~$0.10 |
| S3 + SNS + Cognito | Minimal usage | ~$1 |
| CloudWatch Logs | 14-day retention | ~$0.50 |
| **Total** | | **~$30/month** |
